window.addEventListener('DOMContentLoaded', (e) => {
    setTimeout(()=>{
        $(".loading-overplay").fadeOut(1000)
    },1000)
});