PURPOSE FOR LEARNING - NOT PROFIT

VUI LÒNG MỞ LIVE SERVER ĐỂ CHẠY
HOẶC CŨNG CÓ THỂ TRUY CẬP TẠI: https://konnn04.github.io/TKW22_Phu_Trieu/

Đại học Mở Tp.HCM
Khoa công nghệ thông tin
Lớp DH22IT03
LỚP ITEC1406 - Thiết kế Web (TH100-IT2203)
Giảng viên: Dương Hữu Thành

BÀI TẬP GIỮA KÌ

Chủ đề: Thiết kế trang web về Tạp chí khoa học
Kho lưu dự án: https://github.com/konnn04/TKW22_Phu_Trieu
Thành viên:
+ Nguyễn Thanh Triều - 2251052127
+ Nguyễn Thiên Phú - 2251052093

Thông tin dự án:
- Nguồn tham khảo: www.science.org
- Thông tin: 
-- Số trang: 8
-- Ngôn ngữ lập trình: Javascript
-- Thư viện sử dụng: JQuery
-- Font sử dụng: Awesome, Google Font
-- Khác: MockApi
        

